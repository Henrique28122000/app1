import makeWASocket, { useMultiFileAuthState } from "@whiskeysockets/baileys";
import fs from "fs";
import qrcode from "qrcode-terminal";
import fetch from "node-fetch";

// ===========================
// VARIÁVEIS
// ===========================
let carrinhos = {};
let clientes = {};
let pedidos = [];
let config = {};
let menu = {};
let links = {};

// ===========================
// LER LINKS.JSON
// ===========================
try {
  const data = fs.readFileSync("./links.json", "utf8");
  links = JSON.parse(data);
  console.log("✅ Links carregados:", links);
} catch (err) {
  console.error("❌ Erro ao ler links.json:", err);
}

// ===========================
// CARREGAR CONFIG E MENU
// ===========================
async function carregarConfig() {
  const res = await fetch(links.config);
  config = await res.json();
}

async function carregarMenu() {
  const res = await fetch(links.menu);
  menu = await res.json();
}

// ===========================
// UTILITÁRIOS
// ===========================
if (fs.existsSync("clientes.json")) {
  const rawClientes = fs.readFileSync("clientes.json", "utf8").trim();
  clientes = rawClientes ? JSON.parse(rawClientes) : {};
}

if (fs.existsSync("pedidos.json")) {
  const rawPedidos = fs.readFileSync("pedidos.json", "utf8").trim();
  pedidos = rawPedidos ? JSON.parse(rawPedidos) : [];
}

function salvarClientes() {
  fs.writeFileSync("clientes.json", JSON.stringify(clientes, null, 2));
}

function salvarPedidos() {
  fs.writeFileSync("pedidos.json", JSON.stringify(pedidos, null, 2));
}

function numeroParaEmoji(num) {
  const numerosEmoji = {
    "0": "0️⃣","1": "1️⃣","2": "2️⃣","3": "3️⃣","4": "4️⃣",
    "5": "5️⃣","6": "6️⃣","7": "7️⃣","8": "8️⃣","9": "9️⃣"
  };
  return String(num).split("").map(d => numerosEmoji[d]).join("");
}

function calcularTotal(carrinho) {
  if (!carrinho || !carrinho.itens) return 0;
  return carrinho.itens.reduce((s, i) => s + i.preco * i.qtd, 0);
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ===========================
// FINALIZAR PEDIDO
// ===========================
function gerarNumeroPedido() {
  let ultimo = 0;
  if (pedidos.length > 0) {
    const numeros = pedidos.map(p => parseInt(p.numeroPedido)).filter(n => !isNaN(n));
    ultimo = numeros.length > 0 ? Math.max(...numeros) : 0;
  }
  const novoNumero = ultimo + 1;
  return novoNumero.toString().padStart(4, "0");
}

async function finalizarPedido(sock, user, pedido) {
  pedido.numeroPedido = gerarNumeroPedido();

  await carregarConfig();
  await carregarMenu();

  const dataHora = new Date().toLocaleString("pt-BR", { timeZone: "America/Fortaleza" });
  pedido.dataHora = dataHora;
  pedido.dataHoraISO = new Date().toISOString();

  let itensTxt = "";
  pedido.itens.forEach(i => {
    const nomeItem = i.nome || "Item";
    itensTxt += `${i.qtd}x ${nomeItem}`;
    if (i.obs && i.obs.length > 0) {
      itensTxt += `\n  → ${i.obs.join(" / ")}`;
    }
    itensTxt += "\n";
  });

  const total = pedido.itens.reduce((sum, i) => sum + (i.preco * i.qtd), 0);
  pedido.total = total;

  let resumo = "";
    resumo += `PEDIDO CONFIRMADO!\n`;
  resumo += `======== ${config.empresa} ========\n`;
  resumo += `Pedido n: ${pedido.numeroPedido}\n`;
  resumo += `Data/Hora: ${dataHora}\n`;
  resumo += `Cliente: ${pedido.nome || "Cliente"}\n`;
  resumo += `Endereco: ${pedido.endereco}\n`;
  resumo += `Contato: ${user.replace("@s.whatsapp.net","")}\n`;
  resumo += "-------------------------------\n";
  resumo += "Itens:\n";
  resumo += itensTxt;
  resumo += "-------------------------------\n";
  resumo += `Tipo de pedido: ${pedido.entrega}\n`;
  resumo += `Pagamento: ${pedido.pagamento}`;
  if (pedido.troco) resumo += ` (Troco para R$ ${pedido.troco.toFixed(2)})`;
  resumo += `\nTOTAL: R$ ${total.toFixed(2)}\n`;
  resumo += "===============================\n";
  resumo += `${config.mensagemFinal}\n`;
  resumo += `${config.suporte}\n`;
  resumo += "===============================\n";

  // envia para cliente e dono
  await sock.sendMessage(user, { text: resumo });
  await sock.sendMessage(config.numeroDono + "@s.whatsapp.net", { text: resumo });

  // PIX
  if (pedido.pagamento && pedido.pagamento.toLowerCase() === "pix" && config.chavePix) {
    await delay(5000);
    await sock.sendMessage(user, { text: `${config.aquipix}` });
    await sock.sendMessage(user, { text: `${config.chavePix}` });
    await delay(5000);
    await sock.sendMessage(user, { text: `${config.pedirpagamento}` });
  }

  await delay(3000);
  await sock.sendMessage(user, { text: `${config.obrigado}` });

  salvarPedidos();
  delete carrinhos[user];
}

// ===========================
// START BOT
// ===========================
async function startBot() {
  await carregarConfig();
  await carregarMenu();

  const { state, saveCreds } = await useMultiFileAuthState("auth_info");
  const sock = makeWASocket({ auth: state, printQRInTerminal: false });

  sock.ev.on("connection.update", ({ qr, connection }) => {
    if (qr) qrcode.generate(qr, { small: true });
    if (connection === "open") console.log("✅ Bot conectado!");
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;
    const user = msg.key.remoteJid;
    const textRaw = (msg.message.conversation || msg.message.extendedTextMessage?.text || "").trim();
    const text = textRaw.toLowerCase();

    if (!carrinhos[user]) carrinhos[user] = null;
    let carrinho = carrinhos[user];

    // ===========================
    // RELATÓRIO DONO
    // ===========================
    if (text.startsWith("relatorio") || text.startsWith("relatório")) {
      const args = textRaw.split(" ");
      const senha = args[1] || "";
      if (senha !== config.senhaDono) {
        await sock.sendMessage(user, { text: "❌ Senha inválida." });
        return;
      }

      const hoje = new Date().toLocaleDateString("pt-BR", { timeZone: "America/Fortaleza" });
      const pedidosHoje = pedidos.filter(p => p.dataHoraISO && new Date(p.dataHoraISO).toLocaleDateString("pt-BR", { timeZone: "America/Fortaleza" }) === hoje);

      if (pedidosHoje.length === 0) {
        await sock.sendMessage(user, { text: "📊 Nenhum pedido registrado hoje." });
        return;
      }

      let totalPix = 0, totalCartao = 0, totalDinheiro = 0;
      let resumo = `📊 *Relatório – ${config.empresa}*\n\n`;

      pedidosHoje.forEach((p, i) => {
        resumo += `${i + 1}. ${p.dataHora} – ${p.nome || "Cliente"}\n`;
        resumo += `💳 ${p.pagamento} – R$ ${p.total.toFixed(2)}\n`;
        if (p.itens) {
          resumo += "Itens:\n";
          p.itens.forEach(it => {
            resumo += `  - ${it.qtd}x ${it.nome}`;
            if (it.obs && it.obs.length > 0) resumo += ` (Obs: ${it.obs.join(", ")})`;
            resumo += "\n";
          });
        }
        resumo += "\n";

        if (p.pagamento === "Pix") totalPix += p.total;
        if (p.pagamento === "Cartão") totalCartao += p.total;
        if (p.pagamento === "Dinheiro") totalDinheiro += p.total;
      });

      const totalFinal = totalPix + totalCartao + totalDinheiro;
      resumo += "=====================\n";
      resumo += `⚡ Pix: R$ ${totalPix.toFixed(2)}\n`;
      resumo += `💳 Cartão: R$ ${totalCartao.toFixed(2)}\n`;
      resumo += `💵 Dinheiro: R$ ${totalDinheiro.toFixed(2)}\n`;
      resumo += `\n📌 TOTAL FINAL: R$ ${totalFinal.toFixed(2)}`;

      await sock.sendMessage(user, { text: resumo });
      return;
    }

    // ===========================
    // MENU
    // ===========================
    if (text === "menu") {
      await carregarConfig();
      await carregarMenu();
      carrinhos[user] = { itens: [], status: null, nome: null, endereco: null, pagamento: null, entrega: null };
      carrinho = carrinhos[user];

      let cardapio = `📋 *CARDÁPIO – ${config.empresa}*\n\n`;
      let itensDisponiveis = 0;

      for (let id in menu) {
        if (menu[id].ativo === false) continue; // trata explicitamente ativo=false
        cardapio += `*${numeroParaEmoji(id)}* ${menu[id].nome} – R$ ${menu[id].preco.toFixed(2)}\n\n`;
        itensDisponiveis++;
      }

      if (itensDisponiveis === 0) {
        await sock.sendMessage(user, { text: "⚠ No momento não temos itens disponíveis no menu." });
        return;
      }

      cardapio += config.pedirpagamento;
      await sock.sendMessage(user, { text: cardapio });
      return;
    }

    if (!carrinho) return;

    // ===========================
    // ADICIONAR ITEM (Ex: 1x2)
    // ===========================
    if (/^\d+x\d+$/i.test(text)) {
      const [id, qtd] = text.toLowerCase().split("x");
      if (menu[id] && menu[id].ativo !== false) {
        const item = {
          id,
          nome: menu[id].nome,
          qtd: parseInt(qtd),
          preco: menu[id].preco,
          obs: [],
          opcoes: menu[id].opcoes || [],
          opIndex: 0
        };
        carrinho.itens.push(item);
        carrinho.itemAtual = carrinho.itens.length - 1;

        // Se tiver opções (perguntas), enviar a primeira formatada em lista numerada
        if (item.opcoes.length > 0) {
          carrinho.status = "responderOpcao";
          const primeira = item.opcoes[0];
          const lista = primeira.respostas.map((r, i) => `${i + 1}️⃣ ${r}`).join("\n");
          await sock.sendMessage(user, { text: `❓ ${primeira.pergunta}\n👉 Opções:\n${lista}` });
        } else {
          carrinho.status = null;
          await sock.sendMessage(user, { text: `✅ Adicionado: ${item.qtd}x ${item.nome}` });
          await sock.sendMessage(user, { text: "👉 Deseja adicionar mais itens? (Sim/Não)" });
        }
      } else {
        await sock.sendMessage(user, { text: "⚠ Item inválido ou desativado!" });
      }
      return;
    }

    // ===========================
    // RESPONDER OPÇÕES (OBSERVAÇÕES NUMERADAS)
    // ===========================
    if (carrinho?.status === "responderOpcao") {
      const item = carrinho.itens[carrinho.itemAtual];
      const opcaoAtual = item.opcoes[item.opIndex];

      // tenta interpretar como número (1,2,3...) primeiro
      const escolhaNum = parseInt(text, 10);
      let respostaEscolhida = null;

      if (!isNaN(escolhaNum) && escolhaNum >= 1 && escolhaNum <= opcaoAtual.respostas.length) {
        respostaEscolhida = opcaoAtual.respostas[escolhaNum - 1];
      } else {
        // também aceita o texto exato (sem case)
        const match = opcaoAtual.respostas.find(r => r.toLowerCase() === text || r.toLowerCase() === textRaw.toLowerCase());
        if (match) respostaEscolhida = match;
      }

      if (!respostaEscolhida) {
        // resposta inválida → reenviar lista numerada
        const opcoesNumeradas = opcaoAtual.respostas.map((r, i) => `${i + 1}️⃣ ${r}`).join("\n");
        await sock.sendMessage(user, { text: `⚠ Opção inválida. Escolha uma das seguintes:\n\n${opcoesNumeradas}` });
        return;
      }

      // salvar resposta
      item.obs.push(`${opcaoAtual.pergunta} ${respostaEscolhida}`);

      // avançar para próxima pergunta do mesmo item (se houver)
      item.opIndex++;
      if (item.opIndex < item.opcoes.length) {
        const prox = item.opcoes[item.opIndex];
        const proxOpcoes = prox.respostas.map((r, i) => `${i + 1}️⃣ ${r}`).join("\n");
        await sock.sendMessage(user, { text: `❓ ${prox.pergunta}\n👉 Opções:\n${proxOpcoes}` });
      } else {
        // terminou perguntas do item
        carrinho.status = null;
        await sock.sendMessage(user, { text: `✅ Adicionado: ${item.qtd}x ${item.nome}` });
        await sock.sendMessage(user, { text: "👉 Deseja adicionar mais itens? (Sim/Não)" });
      }
      return;
    }

    // ===========================
    // SIM / NÃO PARA MAIS ITENS
    // ===========================
    if (carrinho.status === null && text === "sim") {
      await sock.sendMessage(user, { text: "📋 Envie o próximo item (Ex: 1x2)" });
      return;
    }
    if (carrinho.status === null && (text === "não" || text === "nao")) {
      carrinho.status = "tipoEntrega";
      await sock.sendMessage(user, { text: "🚚 Deseja *Entrega* ou *Retirada*?" });
      return;
    }

    // ===========================
    // ENTREGA OU RETIRADA
    // ===========================
    if (carrinho.status === "tipoEntrega") {
      if (text === "entrega") {
        carrinho.entrega = "Delivery";
        if (clientes[user]?.endereco) {
          await sock.sendMessage(user, { text: `📍 Usar endereço salvo?\n*${clientes[user].endereco}*\nResponda: Sim/Não` });
          carrinho.status = "usarEndereco";
        } else {
          carrinho.status = "nome";
          await sock.sendMessage(user, { text: "Digite seu nome:" });
        }
        return;
      }
      if (text === "retirada") {
        carrinho.entrega = "Retirada";
        carrinho.endereco = config.enderecoPadrao;
        if (clientes[user]?.nome) {
          carrinho.nome = clientes[user].nome;
          carrinho.status = "pagamento";
          await sock.sendMessage(user, { text: `💳 Forma de pagamento? (Pix / Dinheiro / Cartão)\nTotal: R$ ${calcularTotal(carrinho).toFixed(2)}` });
        } else {
          carrinho.status = "nome";
          await sock.sendMessage(user, { text: "📍 Digite seu nome:" });
        }
        return;
      }
    }

    // ===========================
    // USAR ENDEREÇO SALVO
    // ===========================
    if (carrinho.status === "usarEndereco") {
      if (text === "sim") {
        carrinho.nome = clientes[user]?.nome || "Cliente";
        carrinho.endereco = clientes[user]?.endereco || config.enderecoPadrao;
        carrinho.status = "pagamento";
        await sock.sendMessage(user, { text: `💳 Forma de pagamento? (Pix / Dinheiro / Cartão)\nTotal: R$ ${calcularTotal(carrinho).toFixed(2)}` });
      } else if (text === "não" || text === "nao") {
        carrinho.status = "nome";
        await sock.sendMessage(user, { text: "Digite seu nome:" });
      }
      return;
    }

    // ===========================
    // NOME E ENDEREÇO
    // ===========================
    if (carrinho.status === "nome") {
      carrinho.nome = textRaw || "Cliente";
      carrinho.status = "endereco";
      await sock.sendMessage(user, { text: "📍 Digite seu endereço:" });
      return;
    }
    if (carrinho.status === "endereco") {
      carrinho.endereco = textRaw || config.enderecoPadrao;
      clientes[user] = { nome: carrinho.nome, endereco: carrinho.endereco };
      salvarClientes();
      carrinho.status = "pagamento";
      await sock.sendMessage(user, { text: `💳 Forma de pagamento? (Pix / Dinheiro / Cartão)\nTotal: R$ ${calcularTotal(carrinho).toFixed(2)}` });
      return;
    }

    // ===========================
    // PAGAMENTO
    // ===========================
    if (carrinho.status === "pagamento") {
      if (["pix", "cartão", "cartao"].includes(text)) {
        carrinho.pagamento = text === "cartao" ? "Cartão" : text.charAt(0).toUpperCase() + text.slice(1);
        carrinho.total = calcularTotal(carrinho);
        pedidos.push(carrinho);
        salvarPedidos();
        await finalizarPedido(sock, user, carrinho);
        delete carrinhos[user];
      } else if (text === "dinheiro") {
        carrinho.pagamento = "Dinheiro";
        carrinho.status = "trocoPergunta";
        await sock.sendMessage(user, { text: "💵 Precisa de troco? (Sim/Não)" });
      } else {
        await sock.sendMessage(user, { text: "⚠ Forma inválida. Escolha Pix / Cartão / Dinheiro." });
      }
      return;
    }

    // ===========================
    // TROCO
    // ===========================
    if (carrinho.status === "trocoPergunta") {
      if (text === "sim") {
        carrinho.status = "trocoValor";
        await sock.sendMessage(user, { text: "💰 Para quanto?" });
      } else if (text === "não" || text === "nao") {
        carrinho.troco = null;
        carrinho.total = calcularTotal(carrinho);
        pedidos.push(carrinho);
        salvarPedidos();
        await finalizarPedido(sock, user, carrinho);
        delete carrinhos[user];
      } else {
        await sock.sendMessage(user, { text: "⚠ Resposta inválida. Digite 'Sim' ou 'Não'." });
      }
      return;
    }

    if (carrinho.status === "trocoValor") {
      const valor = parseFloat(text.replace(",", "."));
      if (!isNaN(valor) && valor >= 0) {
        carrinho.troco = valor;
        carrinho.total = calcularTotal(carrinho);
        pedidos.push(carrinho);
        salvarPedidos();
        await finalizarPedido(sock, user, carrinho);
        delete carrinhos[user];
      } else {
        await sock.sendMessage(user, { text: "⚠ Valor inválido. Digite um número válido." });
      }
      return;
    }

  });
}

// ===========================
// INICIA BOT
// ===========================
startBot();
